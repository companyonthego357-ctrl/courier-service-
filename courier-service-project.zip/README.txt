Courier Service — Full Next.js Project

This repository is a ready-to-run Courier Service web app built with Next.js, TailwindCSS, Prisma, and SQLite (easy to switch to Postgres). It includes:

- Admin-only backend login and admin dashboard (for you only).
- User registration/login and user dashboard to create and track parcels (portfolio).
- Parcel management API routes (create, update, list, track).
- Tawk.to live chat integration on every page for customer support.

The full project code is included below as a single-file reference. Copy files into the same directory structure to run locally.

... (Truncated in the README here for brevity)

IMPORTANT:
You can find the full file-by-file code inside the 'FULL_PROJECT_CONTENT.txt' included in this ZIP. That file contains every source file from the scaffold in a single document for easy copy/paste into your project.
